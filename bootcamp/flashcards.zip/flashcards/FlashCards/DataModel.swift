//
//  DataModel.swift
//  Oplossing
//
//  Created by Jille Treffers on 13/05/2018.
//  Copyright © 2018 Jille Treffers. All rights reserved.
//

import Foundation
import UIKit

struct DataModel {
    
    // calculated property that either returns a bogus value or an array of all saved persons. Normally one would use an optional to prevent this bugus value from being necessary.
    var fullPersonList:[Person] {
        get {
            guard let _ = getFullPersonList() else{
                return [Person(imageUrl: "test", name: "No one")]
            }
            return getFullPersonList()!
        }
    }
    
    // calculated property that retrieves the number of persons that were saved.
    var numberOfPersons:Int {
        get{
            if let personList = getFullPersonList() {
                return personList.count
            }
            return 0
        }
    }
    
    //creates the document directory and returns its location as a string
    public func getDocumentDirectoryUrl(named directoryString:String)->String{
        var imagesDirectoryPath:String!
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        // Get the Document directory path
        let documentDirectorPath:String = paths.first!
        // Create a new path for the new images folder
        imagesDirectoryPath = documentDirectorPath + "/" + directoryString
        var objectiveCBool:ObjCBool = true
        
        let isExist = FileManager.default.fileExists(atPath: imagesDirectoryPath, isDirectory: &objectiveCBool)
        // If the folder with the given path doesn't exist already, create it
        if isExist == false{
            do{
                try FileManager.default.createDirectory(atPath: imagesDirectoryPath, withIntermediateDirectories: true, attributes: nil)
            }catch{
                print("Something went wrong while creating a new folder")
            }
            
        }
        return imagesDirectoryPath
    }
    
    //saves image
    public func writeImageToDirectory(name:String, image:UIImage, directory:String)->String?{
        let imagesDirectoryPath = getDocumentDirectoryUrl(named: directory)
        let imagePath = imagesDirectoryPath + "/" + name + ".png"
        let data = UIImagePNGRepresentation(image)
        let success = FileManager.default.createFile(atPath: imagePath, contents: data, attributes: nil)
        if success {
            return imagePath
        }
        return nil
    }
    
    // writes a person as JSON to a plist document named person_list (see "saving data", page 650 of the book)
    public func addPerson(person: Person){
        var newPersonList = [Person]()
        if let personList = getFullPersonList() {
            newPersonList = personList
        }
        newPersonList.append(person)
        let archiveURL = getArchiveURL(of: "person_list")
        
        let propertyListEncoder = PropertyListEncoder()
        let encodedNote = try? propertyListEncoder.encode(newPersonList)
        try? encodedNote?.write(to: archiveURL, options: .noFileProtection)
    }
    
    // temporary function that is used when loading dummy data, the pictures are initially in the pictures folder in our project, but we need them to be in a documents folder where we can also save images we take with our camera. The reason this function is hidden here, is because some students will not be able to understand / work with optionals at this point.
    func addDummyPerson(name: String, projectPictureURL: String){
        let uiImage = UIImage(named: projectPictureURL)
        let randomName = HelperFunctions.randomString(length: 12) + name
        guard let image = uiImage else{
            return
        }
        let possiblePictureUrl = writeImageToDirectory(name: randomName, image: image, directory: "pictures")
        guard let pictureUrl = possiblePictureUrl else{
            return
        }
        let person = Person(imageUrl: pictureUrl, name: name)
        addPerson(person: person)
    }
    
    // empties the entire document.
    public func emptyList(){
         let archiveURL = getArchiveURL(of: "person_list")
        do {
            try "".write(to: archiveURL, atomically: true, encoding: .utf8)
        } catch let error {
            print(error)
        }
    }
    
    // function that retrieves the data from the person_list plist file. It returns an optional, which is not covered at this point in the course. This is negated by utilising a calculated property.
    private func getFullPersonList() -> [Person]?{
        let archiveURL = getArchiveURL(of: "person_list")
        
        let propertyListDecoder = PropertyListDecoder()
        
        guard let retrievedPersonsData = try? Data(contentsOf: archiveURL),
            let decodedPersons = try? propertyListDecoder.decode([Person].self, from: retrievedPersonsData) else {
                return nil
        }
        return decodedPersons
    }
    
    // function that produces the URL used to write and retrieve documents.
    private func getArchiveURL(of urlString: String) -> URL{
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let archiveURL = documentsDirectory.appendingPathComponent(urlString).appendingPathExtension("plist")
        return archiveURL
    }
}

