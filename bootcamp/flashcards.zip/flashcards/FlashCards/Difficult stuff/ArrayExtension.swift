//
//  ArrayExtension.swift
//  Oplossing
//
//  Created by Jille Treffers on 13/05/2018.
//  Copyright © 2018 Jille Treffers. All rights reserved.
//

import Foundation
extension Array {
    
    //the shuffle function does not come standard in Swift, so we just extend the swift Array struct
    mutating func shuffle() {
        for i in 0 ..< (count - 1) {
            let j = Int(arc4random_uniform(UInt32(count - i))) + i
            swapAt(i, j)
        }
    }
}
