//
//  Person.swift
//  Oplossing
//
//  Created by Jille Treffers on 13/05/2018.
//  Copyright © 2018 Jille Treffers. All rights reserved.
//

import Foundation
/*
 implements Codable protocol so it can be stored in a plist.
 Implements hashable protocol so the type can be used in a set.
 */
struct Person: Codable, Hashable{
    let imageUrl:String
    let name:String

    init(imageUrl:String, name:String){
        self.imageUrl = imageUrl
        self.name = name
        
    }
}
