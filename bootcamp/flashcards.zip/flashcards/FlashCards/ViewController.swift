//
//  ViewController.swift
//  FlashCards
//
//  Created by Jille Treffers on 13/05/2018.
//  Copyright © 2018 Jille Treffers. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var game = Game()
    
    @IBOutlet weak var option1: UIButton!
    @IBOutlet weak var option2: UIButton!
    @IBOutlet weak var option3: UIButton!
    @IBOutlet weak var option4: UIButton!
    
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var validationLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    //this method is called when the view is about to be shown the first time.
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //this should be commented out when
        createDummyData()
        
        //only play the game when there are enough persons in the database
        if game.hasEnoughData(){
            //selects four persons to display, and generates the winning number
            game.startNewGame()
            let chosenPersons = game.activePersons
            redrawGameScreen(chosenPersons: chosenPersons)
        }else{
            validationLabel.text = "You should add more persons before playing!"
            nextButton.isEnabled = false
        }
       
    }
    
    //This method is called when you move from one screen to the other, but it was already loaded. We want to redraw the game, because maybe another person was added to the game in one of the other screens.
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        //only play the game when there are enough persons in the database
        if game.hasEnoughData(){
            //selects four persons to display, and generates the winning number
            game.startNewGame()
            let chosenPersons = game.activePersons
            redrawGameScreen(chosenPersons: chosenPersons)
        }else{
            validationLabel.text = "You should add more persons before playing!"
            nextButton.isEnabled = false
        }
    }
    
    //draws buttons with images that are linked to people.
    func redrawGameScreen(chosenPersons:[Person]){
        nextButton.isEnabled = false
        validationLabel.text = ""
        fillButtonWithImage(button: option1, imageUrl: chosenPersons[0].imageUrl)
        fillButtonWithImage(button: option2, imageUrl: chosenPersons[1].imageUrl)
        fillButtonWithImage(button: option3, imageUrl: chosenPersons[2].imageUrl)
        fillButtonWithImage(button: option4, imageUrl: chosenPersons[3].imageUrl)
        nameLabel.text = String(describing: chosenPersons[game.correctAnswer].name)
    }
    
    
    //this method attaches an image to a button
    func fillButtonWithImage(button: UIButton, imageUrl: String){
       // let uiImage = HelperFunctions.fixOrientation(img: !)
        guard let image = UIImage(named:imageUrl) else{
            return
        }
        button.backgroundColor = .clear
        button.setImage(image, for: .normal)
        button.contentMode = .center
        button.imageView?.contentMode = .scaleAspectFit
    }
    

    
    // because there is no functionality to add new persons, here is some hardcoded data
    func createDummyData(){
        //emty the list just for now. REMOVE WHEN YOU STOP USING DUMMY DATA!!!
        game.dataModel.emptyList()
        addDummyPerson(name: "Jille", projectPictureURL: "pictures/jille.jpg")
        addDummyPerson(name: "Johan", projectPictureURL: "pictures/johan korten.jpg")
        addDummyPerson(name: "Bart", projectPictureURL: "pictures/bart.jpg")
        addDummyPerson(name: "Veronique", projectPictureURL: "pictures/veronique.jpg")

    }
    
    // temporary function that is used when loading dummy data, the pictures are initially in the pictures folder in our project, but we need them to be in a documents folder where we can also save images we take with our camera. The reason this function is hidden here, is because some students will not be able to understand / work with optionals at this point.
    func addDummyPerson(name: String, projectPictureURL: String){
        let uiImage = UIImage(named: projectPictureURL)
        let randomName = HelperFunctions.randomString(length: 12) + name
        guard let image = uiImage else{
            return
        }
        let possiblePictureUrl = game.dataModel.writeImageToDirectory(name: randomName, image: image, directory: "pictures")
        guard let pictureUrl = possiblePictureUrl else{
            return
        }
        let person = Person(imageUrl: pictureUrl, name: name)
        game.dataModel.addPerson(person: person)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func nextButton(_ sender: UIButton) {
        game.startNewGame()
        let chosenPersons = game.activePersons
        redrawGameScreen(chosenPersons: chosenPersons)
    }
    
    
    //lots of repetition, maybe we could make this more generic?
    @IBAction func option1Action(_ sender: UIButton) {
        if(game.isCorrect(answer: 0)){
            validationLabel.text = "Correct!"
            nextButton.isEnabled = true
        }else{
            validationLabel.text = "WRONG"
        }
    }
    
    @IBAction func option2Action(_ sender: UIButton) {
        if(game.isCorrect(answer: 1)){
            validationLabel.text = "Correct!"
            nextButton.isEnabled = true
        }else{
            validationLabel.text = "WRONG"
        }
    }
    
    @IBAction func option3Action(_ sender: UIButton) {
        if(game.isCorrect(answer: 2)){
            validationLabel.text = "Correct!"
            nextButton.isEnabled = true
        }else{
            validationLabel.text = "WRONG"
        }
    }
    
    @IBAction func option4Action(_ sender: UIButton) {
        if(game.isCorrect(answer: 3)){
            validationLabel.text = "Correct!"
            nextButton.isEnabled = true
        }else{
            validationLabel.text = "WRONG"
        }
    }
    
    


}

