//
//  HelperFunctions.swift
//  FlashCards
//
//  Created by Jille Treffers on 19/05/2018.
//  Copyright © 2018 Jille Treffers. All rights reserved.
//

import Foundation
import UIKit
class HelperFunctions{
    
    //generates a random string between with a prefered length
    static func randomString(length: Int) -> String {
        let letters : NSString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        let len = UInt32(letters.length)
        var randomString = ""
        
        for _ in 0 ..< length {
            let rand = arc4random_uniform(len)
            var nextChar = letters.character(at: Int(rand))
            randomString += NSString(characters: &nextChar, length: 1) as String
        }
        return randomString
    }
    

  

}
