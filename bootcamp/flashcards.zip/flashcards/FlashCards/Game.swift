//
//  Game.swift
//  Oplossing
//
//  Created by Jille Treffers on 13/05/2018.
//  Copyright © 2018 Jille Treffers. All rights reserved.
//

import Foundation
struct Game {
    
    var correctAnswer:Int = 0 //value is set with every round (0 because optionals not covered).
    var dataModel:DataModel
    var activePersons:[Person] = [Person]()
    
    init(){
        dataModel = DataModel()
    }
    
    //checks whether or not there is enough data to play a round
    public func hasEnoughData()->Bool{
        if(dataModel.numberOfPersons > 3){
            return true
        }else{
            return false
        }
    }
    
    //checks whether or not the given answer is correct
    public func isCorrect(answer:Int)->Bool{
        if answer == correctAnswer {
            return true
        }else{
            return false
        }
    }
    
    // creates a new round
    mutating public func startNewGame()->Void{
        correctAnswer = getRandomNumberBetween0(and: 4)
        activePersons = getFourRandomPersons()
        activePersons.shuffle()
    }
    
    // function that returns four unique persons from the document
    private func getFourRandomPersons()->[Person]{
        let newSet = Set<Person>()
        let fourUniquePersonsSet = addFourUniquePersonsRecursively(uniquePersons: newSet)
        return [Person](fourUniquePersonsSet)
        
    }
    
    // function that recursively fills a set with four unique persons. It returns a set. Set is used instead of Array because sets cannot contain the same item twice, and they have a nice "contains" method.
    private func addFourUniquePersonsRecursively(uniquePersons:Set<Person>)->Set<Person>{
        var personSet = uniquePersons
        let person = getRandomPersonFromList()
        if !personSet.contains(person){
            personSet.insert(person)
        }
        if(personSet.count < 4){
            personSet = addFourUniquePersonsRecursively(uniquePersons: personSet)
        }
        return personSet
      
    }
    
    //retrieves a random person from the dataset
    private func getRandomPersonFromList() -> Person{
        let maxIndex = dataModel.numberOfPersons
        let randomNumber = getRandomNumberBetween0(and: maxIndex)
        return dataModel.fullPersonList[randomNumber]
    }
    
    //generates a random number between 0 and an upperbound
    private func getRandomNumberBetween0(and upper:Int)->Int{
        return Int(arc4random_uniform(UInt32(UInt(upper))))
    }
    
}
