//
//  NameGameViewController.swift
//  FlashCards
//
//  Created by Jille Treffers on 19/05/2018.
//  Copyright © 2018 Jille Treffers. All rights reserved.
//

import UIKit

class NameGameViewController: UIViewController {
    var game = Game()
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var option1: UIButton!
    @IBOutlet weak var option2: UIButton!
    @IBOutlet weak var option3: UIButton!
    @IBOutlet weak var option4: UIButton!
    @IBOutlet weak var validationLabel: UILabel!
    @IBOutlet weak var nextButton: UIButton!
    @IBAction func nextButtonClicked(_ sender: UIButton) {
        game.startNewGame()
        let chosenPersons = game.activePersons
        redrawGameScreen(chosenPersons: chosenPersons)
    }
    @IBAction func option1Clicked(_ sender: UIButton) {
        if(game.isCorrect(answer: 0)){
            validationLabel.text = "Correct!"
            nextButton.isEnabled = true
        }else{
            validationLabel.text = "WRONG"
        }
    }

    @IBAction func option2Clicked(_ sender: UIButton) {
        if(game.isCorrect(answer: 1)){
            validationLabel.text = "Correct!"
            nextButton.isEnabled = true
        }else{
            validationLabel.text = "WRONG"
        }
    }
    
    @IBAction func option3Clicked(_ sender: UIButton) {
        if(game.isCorrect(answer: 2)){
            validationLabel.text = "Correct!"
            nextButton.isEnabled = true
        }else{
            validationLabel.text = "WRONG"
        }
    }
    
    @IBAction func option4Clicked(_ sender: UIButton) {
        if(game.isCorrect(answer: 3)){
            validationLabel.text = "Correct!"
            nextButton.isEnabled = true
        }else{
            validationLabel.text = "WRONG"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //only play the game when there are enough persons in the database
        if game.hasEnoughData(){
            //selects four persons to display, and generates the winning number
            game.startNewGame()
            let chosenPersons = game.activePersons
            redrawGameScreen(chosenPersons: chosenPersons)
        }else{
            nextButton.isEnabled = false
            validationLabel.text = "You should add more persons before playing!"
        }
        // Do any additional setup after loading the view.
    }
    
    //draws buttons with images that are linked to people.
    func redrawGameScreen(chosenPersons:[Person]){
        nextButton.isEnabled = false
        validationLabel.text = ""
        option1.setTitle(chosenPersons[0].name, for: .normal)
        option2.setTitle(chosenPersons[1].name, for: .normal)
        option3.setTitle(chosenPersons[2].name, for: .normal)
        option4.setTitle(chosenPersons[3].name, for: .normal)
        
        guard let image = UIImage(named:chosenPersons[game.correctAnswer].imageUrl) else{
            return
        }
        imageView.image = image
        
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        //createDummyData()
        
        //only play the game when there are enough persons in the database
        if game.hasEnoughData(){
            //selects four persons to display, and generates the winning number
            game.startNewGame()
            let chosenPersons = game.activePersons
            redrawGameScreen(chosenPersons: chosenPersons)
        }else{
            validationLabel.text = "You should add more persons before playing!"
            nextButton.isEnabled = false
        }
    }
    

}
