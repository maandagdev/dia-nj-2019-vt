//
//  AddPersonViewController.swift
//  FlashCards
//
//  Created by Jille Treffers on 19/05/2018.
//  Copyright © 2018 Jille Treffers. All rights reserved.
//

import UIKit
import Photos

//TODO: REMOVE The empty list method from the viewcontroller class or you will never see the fruits of your work
class AddPersonViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var selectPhotoButton: UIButton!
    @IBOutlet weak var takePhotoButton: UIButton!
    
    
    let game = Game()
    let imagePicker = UIImagePickerController()
    
    //property observer used to enable/disable the save button
    var activeImage:UIImage?{
        didSet{
            if name != nil && activeImage != nil{
                saveButton.isEnabled = true
            }else{
                saveButton.isEnabled = false
            }
        }
    }
    
    //property observer used to enable/disable the save button
    var name:String?{
        didSet{
            if name != nil && activeImage != nil{
                saveButton.isEnabled = true
            }else{
                saveButton.isEnabled = false
            }
        }
    }
    
    //is called when take photo button is clicked
    @IBAction func takePhoto(_ sender: UIButton) {
        imagePicker.allowsEditing = false
        imagePicker.sourceType = .camera
        present(imagePicker, animated: true, completion: nil)
    }
    
    //is called when the select photo button is clicked
    @IBAction func selectPhoto(_ sender: UIButton) {
        imagePicker.allowsEditing = false
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    //is called when save button was clicked
    @IBAction func saveButtonClicked(_ sender: UIButton) {
        guard let personName = name else{
            return
        }
        guard let image = activeImage else{
            return
        }
        let randomName = HelperFunctions.randomString(length: 12) + personName
        
        //save image to phone
        let possibleImageUrl = game.dataModel.writeImageToDirectory(name: randomName, image: image, directory: "pictures")
        
        //if saving went wrong, escape
        guard let imageUrl = possibleImageUrl else{
            return
        }
        //save person to document
        let person = Person(imageUrl: imageUrl, name: personName)
        game.dataModel.addPerson(person: person)
        
        //reset all fields
        name = nil
        nameField.text = nil
        activeImage = nil
        imageView.image = nil
        
    }
    
    //is called when "done" is clicked on the keyboard
    @IBAction func editDoneClicked(_ sender: UITextField) {
        guard let nameString = sender.text else{
            return
        }
        self.name = nameString
        
        if nameString == ""{
            self.name = nil
        }
        view.endEditing(true)
    }
    
    //is called when text was edited
    @IBAction func editTextChanged(_ sender: UITextField) {
        if let nameString = sender.text{
            if(nameString != ""){
                 self.name = nameString
            }else{
                 self.name = nil
            }
           
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        saveButton.isEnabled = false
        imagePicker.delegate = self
        
        //ask for permission to use the media library
        checkPermission()
        
        //respond to keyboard events to make the content scroll up.
        NotificationCenter.default.addObserver(self, selector: #selector(AddPersonViewController.keyboardWillShow), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(AddPersonViewController.keyboardWillHide), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
    }
    
    //delegate method that is called when either the camera or the library has selected a photo
    @objc func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            //show the photo in the view
            imageView.contentMode = .scaleAspectFill
            imageView.image = pickedImage
            //save the image with the right orientation (fixOrientation is extenstion on UIImage)
            let fixOrientationImage = pickedImage.fixOrientation()
            activeImage = fixOrientationImage
            
        }
        
        dismiss(animated: false, completion: {print("Klaar")})
    }
    //delegate method that is called when nothing was selected but cancel was clicked
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    //move the view up when the keyboard shows.
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0{
                self.view.frame.origin.y -= keyboardSize.height
            }
        }
    }
    //move the view back down when the keyboard shows.
    @objc func keyboardWillHide(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y != 0{
                self.view.frame.origin.y += keyboardSize.height
            }
        }
    }
    
    // function that asks for photo related permissions
    func checkPermission() {
        let photoAuthorizationStatus = PHPhotoLibrary.authorizationStatus()
        switch photoAuthorizationStatus {
        case .authorized:
            print("Access is granted by user")
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization({
                (newStatus) in
                print("status is \(newStatus)")
                if newStatus ==  PHAuthorizationStatus.authorized {
                    /* do stuff here */
                    print("success")
                }
            })
            print("It is not determined until now")
        case .restricted:
            // same same
            print("User does not have access to photo album.")
        case .denied:
            // same same
            print("User has denied the permission.")
        }
    }


}
