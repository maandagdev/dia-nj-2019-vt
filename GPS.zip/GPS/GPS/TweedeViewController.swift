//
//  TweedeViewController.swift
//  GPS
//
//  Created by Jille Treffers on 9/3/19.
//  Copyright © 2019 Jille Treffers. All rights reserved.
//

import UIKit

class TweedeViewController: UIViewController {

    @IBOutlet weak var dataLabel: UILabel!
    var dataString:String?
    var person: Person?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let person = person{
            dataLabel.text = person.lastName
        }
        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
