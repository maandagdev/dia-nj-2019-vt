
//
//  Person.swift
//  GPS
//
//  Created by Jille Treffers on 9/3/19.
//  Copyright © 2019 Jille Treffers. All rights reserved.
//

import Foundation

struct Person: Codable{
    var firstName:String
    var lastName:String
}
