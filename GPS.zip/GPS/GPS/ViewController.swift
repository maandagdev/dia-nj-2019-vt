//
//  ViewController.swift
//  GPS
//
//  Created by Jille Treffers on 9/3/19.
//  Copyright © 2019 Jille Treffers. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate, UITextViewDelegate, UITableViewDataSource, UITableViewDelegate {


    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var gpsLabel: UILabel!
    
    @IBOutlet weak var superTextViwe: UITextView!
    
    @IBOutlet weak var tableView: UITableView!
    
    var locationManager = CLLocationManager()
    var persons = [Person(firstName: "Coen", lastName: "Pannenkoek"), Person(firstName: "Diede", lastName: "Troost")]

    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
        locationManager.startUpdatingHeading()
        superTextViwe.delegate = self
        textView.delegate = self
        tableView.dataSource = self
        tableView.delegate = self
        
        let dataManager = DataManager()
        dataManager.save(persons: persons)
        
        let newPersons = dataManager.loadPersons()
        print(newPersons)
        // Do any additional setup after loading the view.
    }
    

    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        //print(locations.first?.coordinate.latitude)
    }
    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
       // print(newHeading)
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        textView.text = ""
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return persons.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "nameCell")!
        cell.textLabel?.text = persons[indexPath.row].firstName
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       // performSegue(withIdentifier: "gotoDetail", sender: nil)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destinationVC = segue.destination as? TweedeViewController{
            guard let indexPath = tableView.indexPath(for: (sender as? UITableViewCell)!) else { return }
            
            destinationVC.person = persons[indexPath.row]
        }
    }
    
    
    
    
    
    
}

