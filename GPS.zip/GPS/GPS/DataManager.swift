//
//  DataManager.swift
//  GPS
//
//  Created by Jille Treffers on 9/3/19.
//  Copyright © 2019 Jille Treffers. All rights reserved.
//

import Foundation

struct DataManager{
    
    func save(persons: [Person]){
        let archiveURL = getArchiveURL(of: "personList")
        let jsonEncoder = JSONEncoder()
       
        let possiblePersonData = try? jsonEncoder.encode(persons)
        guard let personData = possiblePersonData else { return }
        try? personData.write(to: archiveURL)
        
        
    }
    
    func loadPersons()->[Person]?{
        let archiveURL = getArchiveURL(of: "personList")
        let possibleData = try? Data(contentsOf: archiveURL)
        guard let data = possibleData else { return nil }
        let jsonDecoder = JSONDecoder()
        let possiblePersons = try? jsonDecoder.decode([Person].self, from: data)
        guard let persons = possiblePersons else { return nil }
        
        return persons
    }
    
    private func getArchiveURL(of urlString: String) -> URL{
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        
        let archiveURL = documentsDirectory.appendingPathComponent(urlString).appendingPathExtension("json")
        return archiveURL
    }
}
